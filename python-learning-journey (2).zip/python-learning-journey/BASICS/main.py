
# Online Python - IDE, Editor, Compiler, Interpreter

print(" my name is sinjini","my age is 23")
print(45+98)
name= "Sinjini"
age= 23
bill=65.98
print(name)
print(age)
print(name,age,bill)
print("My name is",name,",My age is :",age,",the bill is:", bill)
age2=age
print(age2)
print(type(age))
print(type(name))
print(type(bill))
say=True
print(say)
a=None
print(a)