a=2
b=5
sum=a+b
print(sum)
# single line
""" used for multiple line comments """
# arithmetic
# Relational\
a=50
b=20
print(a==b)
print(a!=b)
#assignment
num=10
num=num+10
print(num)
num+=10
print(num)
num**10
print(num)
#logical- not and or
print(not(a>b))

