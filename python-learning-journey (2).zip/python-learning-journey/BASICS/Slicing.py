str="college"
print(str[6:8])
print(str[-5:-1])
print(str.endswith("e"))
print(str.capitalize())
print(str.replace("e","a"))
print(str.find("r"))
print(str.count("e"))

#fname=(input("enter your first name: "))
#print(len(fname))

str1="ente$r any string$ of u$r choice"
print(str1.count("$"))

