#check odd or even...
num=int(input("enter a number"))
if(num%2==0):
    print("the number is even")
else:
    print("the number is odd")
    
# greatest of 3 numbers.
a=input("enter any number")
b=input("enter any number")
c=input("enter any number")
if(a>b and a>c):
    print("a is greatest")
elif(b>c and b>a):
    print("b is greatest")
else:
    print("c is greatest")

#Check a number is multiple of 7.
num1=int(input("enter a number"))
if(num1%7==0):
    print("the number multiple of 7")
else:
    print("the number is not multiple of 7")
    
