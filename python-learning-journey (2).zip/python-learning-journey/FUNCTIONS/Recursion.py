# afunction calls itself repeatedly
def show(n):
    if(n==-1):#base case
        return
    print(n)
    show(n-1)
    print("end")
show(3)

#factorial
def fact(n):
    if(n==0 or n==1):
        return 1
    return fact(n-1)* n
print(fact(4))

#calculate sum of n natural numbers
def sum(n):
    if(n==0):
        return 0
    print(n)
    return sum(n-1) +n
s=sum(90)
print(s)

#print all elements in a list
list=["a","b","c","d","e","f","g"]
def print_list(list,indx=0):
    if(indx==len(list)):
        return
    print(list[indx])
    print_list(list,indx+1)
    
list=["a","b","c","d","e","f","g"]
print_list(list)