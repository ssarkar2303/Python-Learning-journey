# built in functions and user functions.
#default parameters/ values, 2nd val has to be default!!
def calprod(a=8,b=4):
    print(a*b)
    return a*b
calprod()

#practice
#to print the lenght of the list
cities=["kolkata","pune","mumbai","chennai"]
def prinlen(lists):
    print(len(lists))
prinlen(cities)
# WAF to print the elements in single line
cities=["kolkata","pune","mumbai","chennai"]
def line(lists):
    for item in lists:
        print(item, end=" ")
line(cities)
print()

#write the func to weitr factorial of n.para-n
n=5
def fact(n):
    facto=1
    for i in range(1,n+1):
        facto*=i
    print(facto)
fact(5)

# USD TO INR 1usd=83 INR
def converter(usdval):
    inrval= usdval*83
    print(usdval,"USD=",inrval,"INR")
converter(90)

#function to input no.
def checker(num):
    if(num%2==0):
        print("EVEN")
    else:
        print("ODD")
checker(8)
