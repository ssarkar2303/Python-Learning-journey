#block of statement that perforns a specific task.
#to reduce redundancy
def cal_sum(a,b):
    sum=a+b
    print (sum)
    return sum
cal_sum(5,10)
cal_sum(6,19)

def sum(a,b):
    return a+b
val=sum(9883,67587878)
print(val)
#avg of 3 nos.
def avg(a,b,c):
    return (a+b+c)/3
cal=avg(67,87,43)
print(cal)
print(avg(78,65,92))

