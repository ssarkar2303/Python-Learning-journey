# python can be used to perform operations on a file. read and write data.
#ram= read only memory volatile in nature.
# types of file:- text(.txt,.doc,.log) binary files(mp4, .mov,.png,.jpeg)
#f= open("file_name","mode")
f=open("C:\Users\sinji\Documents\Downloads\again.jpeg", "rb")
data=f.read()
print(type(data))
f.close()