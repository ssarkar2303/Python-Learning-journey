#If if(condition)

age=21

if(age>=18):
    print("can vote and apply for liscense")
    print("can drink")
    
#elif(always use an is ststement before elif)
#and we can write as many if statements we want
#elif will only check when the if statement is not satisfied

light="pink"

if(light=="red"):
    print("Stop")
elif(light=="green"):
    print("go")
elif(light=="yellow"):
    print("be ready")
else:
    print("light is broken")
print("end of code")

#else statement should be written only once and last.