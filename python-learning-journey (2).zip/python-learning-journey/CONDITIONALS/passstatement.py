for i in range(5):#if we want to skip the loop.or null statement.
    pass
print(" some work")

#practice find sum of first n numbers
#i=1;while i<=n: sum+=i;i+=1
n=10
sum=0
for i in range (1,n+1):
    sum+=i
    
print(sum)

#factorial n natural number
n=int(input("enter any number"))
fact=1
for i in range(1,n+1):
    fact*=i
print("factorial=",fact)
    
