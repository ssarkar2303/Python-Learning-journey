str1= "This is a string"
str2='college'
len2=len(str2)# to find length.
str="""this is a string"""
#we use the double quotes to use apostrophes
str3="this is a string.\n We are creating in python"
print(str3)#this is used for next line.
print(str1+str2)
print(len2)
print(str2[6])
