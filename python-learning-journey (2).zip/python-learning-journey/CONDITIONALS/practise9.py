marks = int(input("Enter the marks: "))

if(marks >= 90):
    print("grade=A")

elif(marks < 90 and marks <= 80):
    print("grade=B")

elif(marks < 80 and marks >= 70):
    print("grade=C")

else:
    print("grade=D")
    
#nested writing one statement within another statement
age=45
if(age>=18):
    if(age>=80):
        print("cannot drive")
    else:
        print("can drive")
else:
    print("cannot drive")