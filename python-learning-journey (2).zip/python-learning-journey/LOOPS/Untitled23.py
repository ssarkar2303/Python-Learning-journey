#search for a no. in the list.
tups=(1,4,9,16,25,36,49,64,81,100)
x=36
i=0
while i<len(tups):
    if(tups[i]==x):
    
       print("found at index:",i)
       break
    i+=1
print("end of loop")

#break and continue -
i=1
while i<=5:
    print(i)
    if(i==3):
        break
    i+=1
print("end of loop")

#continue-correct iteration is terminated and moves on with the next
i=0
while i<=5:
    
    if(i==3):#(i%2==0)just to print only odd numbers.
        i+=1
        continue#skip
    print(i)
    i+=1
        
        
