#range retuirns a sequence of number starting from 0 by default,
#and increament by one(default),stops before a 
#specified number
#range(start?,stop,step?)

#for i in range(2,10,2):
  #  print(i)
#practice.
for a in range(100,0,-1):
    print(a)

#practice
n=int(input("enter any nember"))
for mul in range(1,11):
    
    print(n*mul)