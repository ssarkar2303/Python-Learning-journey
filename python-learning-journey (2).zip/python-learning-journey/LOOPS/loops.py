#loops are used to repeat the instructions.
"""while loop -while conditions & For loop"""
#while condition:
    #some work
count=1
while count<=5 :
    print("hello")
    count+=1
print(count)

i=1
while i<=10:
    print("sinjini",i)
    i+=1

i=5
while i>=1:
    print("Sarkar",i)
    i-=1