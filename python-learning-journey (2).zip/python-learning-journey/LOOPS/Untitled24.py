#for loop for sequencial traversl in list string, tuples
list=[1,2,3]
for num in list:
    print(num)

vegies=["potato","tomato","carrot"]
for val in vegies:
    print(val)

tup=(1,2,3,4,5,6,7,8)
for num in tup:
    print(num)

string="Sinjini"
for char in string:
    print(char)