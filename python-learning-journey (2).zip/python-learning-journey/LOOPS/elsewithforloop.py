
string="Sinjoini"
for char in string:
    if(char=='o'):
        print("o found")
        break
    print(char)
    
else:
    print("end")
    
# practice 1
list=[1,4,9,16,25,36,49,64,81,100]
for i in list:
    print(i)

#search for a no.linear search
tup=(1,4,16,25,36,49,64,81,100)
x=36
idx=0
for i in tup:
    if(i==x):
        print("found the number at index",idx)
        idx+=1
        break
    idx+=1
