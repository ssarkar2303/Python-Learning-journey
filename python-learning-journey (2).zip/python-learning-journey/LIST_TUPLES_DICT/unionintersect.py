set1={1,2,3}
set2={1,4,5}
print(set1.union(set2))
print(set1.intersection(set2))

#practice.
dict={
    "table":["a piece of furniture","list of facts& figures"],
    "cat":"a small animal"
}
print(dict)
#practice 2
classroom={"python","java","C++","python","javascript","java","python","java","C++","C"}
print(len(classroom))

#practice3
marks={}
x=int(input("enter the marks"))
marks.update({"phy":x})
y=int(input("enter the marks"))
marks.update({"chem":y})
z=int(input("enter the marks"))
marks.update({"bio":z})
print(marks)

#practice4
set={9,"9.0"}
print(set)

