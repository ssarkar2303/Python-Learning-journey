movies=[]
a=input("enter name of movie :")
b=input("enter name of movie :")
c=input("enter name of movie :")
movies.append(a)
movies.append(b)
movies.append(c)
print(movies)

movies=[]
movies.append(input("enter name of movie:"))
movies.append(input("enter name of movie:"))
movies.append(input("enter name of movie:"))
print(movies)


