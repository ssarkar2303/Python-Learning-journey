#here we can create a dictionary with the excisting keyword
student={
    "name":"Sinjini Sarkar",
    "marks": {
        "89":"chem",
        "90":"phy",
        "95":"bio"
    }
}
print(student)
print(student["marks"]["89"])