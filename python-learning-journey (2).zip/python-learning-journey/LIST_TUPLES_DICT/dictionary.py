#dic works in pair to store key data value 
#key:value(dictionary is mutable)do not allow dublicate keys
info={
    "key":"value",
    "name" : "Sinjini",
    "age " : "23",
    "marks":94.5,
    "subjects":["python","java","C++"],
    "topics":("dict","set"),
    12:8799
    
}
info["name"]="Sharanya"
info["surname"]="Sarkar"
print(info["name"])
print(info["subjects"])

nulldict={}
print(nulldict)