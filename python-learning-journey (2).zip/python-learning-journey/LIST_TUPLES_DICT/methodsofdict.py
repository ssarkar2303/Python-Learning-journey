#key method
student={
    "name":"Sinjini Sarkar",
    "marks": {
        "89":"chem",
        "90":"phy",
        "95":"bio"
    }
}
print(len(student))
print(len(list(student.keys())))
print(list(student.keys()))

#Values method mydict.Values()
print(student.values())
print(list(student.values()))

#mydict.items()
print(student.items())
pairs=(list(student.items()))
print(pairs[0])

#mydict.get()
print(student.get("name"))

#mydict.update(new dict)
newdict={"city":"Kolkata","age":"19"}
student.update(newdict)
print(student)


