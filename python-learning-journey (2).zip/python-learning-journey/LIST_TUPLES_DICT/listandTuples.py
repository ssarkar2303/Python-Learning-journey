#built in data type to store values(lists)
#Strings are imutable and lists are mutable.
marks=[94.4,79,98,66,45.9,89.79]
print(type(marks))
print(marks[3])
print(len(marks))
stud=["sinjini",85,23,'A',"Kolkata"]
print(stud[0])
stud[0]="Sharanya"
print(stud)
print(stud[1:5])
