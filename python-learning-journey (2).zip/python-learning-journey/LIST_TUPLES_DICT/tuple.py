#tuple is a builtin datatype which is immutable
list=(5,8,6,9)
print(list[0])
#tup[0]=7 cannot be done!!

tup=(1,2,3,4,5,)
print(tup)
print(type(tup))

print(tup.index(1))#gives the index of the value
print(tup.count(5))# no. of times the value occured
