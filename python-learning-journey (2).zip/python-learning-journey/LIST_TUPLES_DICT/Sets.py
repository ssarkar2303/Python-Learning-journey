#set is collection of unorderd items. each element is unique and immuatable.
#list and dictionary cannot be stored.
#it will ignore dublicate values.mutablebut the elements are immutable.
collection={1,3,5,7,7,7,5}
print(collection)
print(type(collection))
print(len(collection))

#add()/ remove()
(collection.add(8))
print(collection)
(collection.remove(7))
print(collection)
collection.add((2,4,6,9))
print(collection)

#clear
print(collection.clear())
print(len(collection))

#random value pop()
ludo={1,2,3,4,5,6}
print(ludo.pop())
print(ludo.pop())
print(ludo.pop())

#Does set.pop() return a random element?
#Answer: No. It returns an arbitrary element, 
#which depends on Python's internal implementation.
#If you need a random element, use random.
#choice() on a list or tuple converted from the set.
