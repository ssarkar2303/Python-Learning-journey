list=[5567566]
print(list.copy())
print(list.reverse())
if(list.copy()==list.reverse()):
    print("palindrome")
else:
    print("not a palindrome")

#count no.of students with grade a in the given tuple store vale in list and sort them
grade=["c","d","a","a","b","b","a"]
grade.sort()
print(grade)

list1=["c","d","a","a","b","b","a"]
print(list1.sort())