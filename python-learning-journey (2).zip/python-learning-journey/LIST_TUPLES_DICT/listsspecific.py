#append(add at the last)
list=[2,1,3]
list.append(4)
print(list)

#Sort(ascending and descending)
print(list.sort())
print(list)

list=["sinjini","Anushree","Tapi"]
print(list.sort(reverse=True))
print(list)

list=["sinjini","Anushree","Tapi"]
list.reverse()
print(list)

list=[2,7,9,4,8,1]
list.insert(1,5)
print(list)
list.remove(1)
print(list)
list.pop(2)
print(list)


